---@meta

---@class cc.EaseBounce :cc.ActionEase
local EaseBounce = {}
cc.EaseBounce = EaseBounce
