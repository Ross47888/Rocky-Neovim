---@meta
local resty_core_exit = {}
resty_core_exit.version = require("resty.core.base").version
return resty_core_exit
