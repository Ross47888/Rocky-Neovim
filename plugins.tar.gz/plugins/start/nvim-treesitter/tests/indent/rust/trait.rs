struct Foo;

trait Bar {
    fn bar();
}

impl Bar for Foo {
    fn bar() {

    }
}
