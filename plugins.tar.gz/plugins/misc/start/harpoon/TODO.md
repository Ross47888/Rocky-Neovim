### Manage A Mark 1.0
* Logo
* floating term / split term
* TODO: Fill me in, that one really important thing....
* README.md

### Harpoon (upon requests)
* Add hooks for vim so that someone can make it for me
* ackshual tests.
* interactive menu
* cycle
* make setup() callable more than once and just layer in the commands
