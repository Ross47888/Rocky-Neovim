require 'command.auto-require'
