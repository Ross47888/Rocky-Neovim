require 'bee.filewatch'.create():add('中文文件夹')
