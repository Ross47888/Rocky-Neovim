require 'basic.textmerger'
require 'basic.filewatch'
