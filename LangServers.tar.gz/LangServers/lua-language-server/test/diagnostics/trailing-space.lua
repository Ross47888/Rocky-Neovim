TEST [[
<!    !>
]]

TEST [[

<!    !>
]]

TEST [[
X = 1<!  !>
]]

TEST [[
X = [=[  
    ]=]
]]

TEST [[
-- xxxx  
]]

TEST [[
-- [=[  
   ]=]
]]

TEST [=[
return [[   
    
]]
]=]
