TEST [[
---@cast <!x!> integer
]]

TEST [[
local x, y
---@cast y number
]]
