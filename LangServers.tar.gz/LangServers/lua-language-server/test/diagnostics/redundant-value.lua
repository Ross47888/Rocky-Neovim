TEST [[
local _ = 1, <!2!>
]]

TEST [[
_ = 1, <!2!>
]]
